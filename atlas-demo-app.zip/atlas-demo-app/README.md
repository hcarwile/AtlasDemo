# Atlas Demo App

A public-safe static demo bundle for GitHub Pages.

## What's inside
- `index.html` — landing page
- `pages/dashboard.html` — sanitized dashboard
- `pages/outreach.html` — outreach workflow demo
- `pages/purchase.html` — purchase estimate demo
- `pages/refi.html` — refinance estimate demo
- `pages/second.html` — second-lien demo
- `pages/preapproval.html` — pre-approval + scenario demo
- `assets/shared.css` — shared styles
- `assets/demo-data.js` — fictional sample data

## Publish to GitHub Pages
1. Create a new repo.
2. Upload all files in this folder.
3. Keep `index.html` at the repo root.
4. In GitHub, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select your main branch and `/ (root)`.
7. Save.

## Privacy design
- No real borrower names
- No real phone numbers or personal email
- No real company name
- No actual pipeline or client data
- No backend, auth, API keys, or hidden credentials

## Customizing safely
Edit `assets/demo-data.js` if you want different sample numbers or names.
