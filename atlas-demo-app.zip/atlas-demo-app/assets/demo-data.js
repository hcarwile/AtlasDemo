window.DEMO = {
  brand: {
    app: 'Atlas Demo',
    company: 'North Pine Lending',
    advisor: 'Alex Mercer',
    advisorTitle: 'Senior Mortgage Advisor',
    email: 'alex@northpinelending.demo',
    phone: '(704) 555-0186',
    nmls: 'NMLS 2149087'
  },
  dashboard: {
    snapshotDate: 'April 2026',
    fundedMonth: '$2.84M',
    appsThisMonth: 17,
    pullThrough: '34%',
    avgResponse: '4.2 min'
  },
  outreach: {
    contacts: 146,
    conversations: 39,
    apps: 11,
    locks: 6,
    topSegments: [
      ['Recent Close Check-ins', 38],
      ['Cash-Out Opportunities', 31],
      ['Purchase Pre-Approval', 27],
      ['Credit Improvement', 22]
    ],
    queue: [
      ['Taylor M.', '6-month check-in', 'Email drafted'],
      ['Jordan & Casey', 'Cash-out follow-up', 'Call scheduled'],
      ['Morgan S.', 'Rate drop watch', 'Monitoring'],
      ['Chris P.', 'Pre-approval refresh', 'Docs pending']
    ]
  },
  purchase: {
    borrower: 'Sample Borrower',
    property: 'New construction purchase',
    loanAmount: '$512,400',
    purchasePrice: '$640,000',
    rate: '6.125%',
    payment: '$3,114',
    cashToClose: '$27,860',
    ltv: '80.1%',
    closingCosts: '$11,940',
    sellerCredit: '$6,000'
  },
  refi: {
    borrower: 'Demo Client',
    purpose: 'Rate-term refinance',
    currentBalance: '$418,700',
    newLoan: '$432,900',
    rate: '5.875%',
    payment: '$2,560',
    monthlySavings: '$284',
    breakeven: '26 months'
  },
  second: {
    borrower: 'Example Household',
    lineAmount: '$85,000',
    combinedLtv: '78%',
    rate: '8.375%',
    drawPayment: '$593',
    fixedPayment: '$724',
    useOfFunds: ['Kitchen remodel', 'High-interest debt payoff', 'Emergency reserve']
  },
  preapproval: {
    buyer: 'Qualified Buyer',
    maxPurchase: '$485,000',
    targetPayment: '$3,020',
    downPayment: '$32,000',
    loanType: 'Conventional 30-Year Fixed',
    status: 'Demo-approved subject to full underwriting review'
  },
  scenario: {
    homeValue: '$545,000',
    currentMortgage: '$352,000',
    desiredCashOut: '$46,000',
    refiPayment: '$2,846',
    secondLienPayment: '$611',
    blendPayment: '$2,398'
  }
};
